import DoubleArcKpi from './Components/DoubleArc/DoubleArcKpi';
import ArcKpi from './Components/Arc/ArcKpi';
import HalfArcKpi from './Components/HalfArc/HalfArcKpi';

export {
  DoubleArcKpi,
  ArcKpi,
  HalfArcKpi,
};
