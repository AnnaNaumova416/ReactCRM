                                              {/*<li className="">
                                                <Link to="/contractlist"> Created
                                                <sup>
                                                        <span className="counter">
                                                            <b className="badge bg-danger"></b>
                                                        </span>

                                                    </sup>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link to="/contractlist"> Approval Pending
                                                <sup>
                                                        <span className="counter">
                                                            <b className="badge bg-danger"></b>
                                                        </span>

                                                    </sup>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link to="/contractlist"> ReDraft
                                                <sup>
                                                        <span className="counter">
                                                            <b className="badge bg-danger"></b>
                                                        </span>

                                                    </sup>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link to="/contractlist"> Completed
                                                <sup>
                                                        <span className="counter">
                                                            <b className="badge bg-danger"></b>
                                                        </span>

                                                    </sup>
                                                </Link>
                                            </li>
                                            <li className="">
                                                <Link to="/contractlist"> Hidden
                                                <sup>
                                                        <span className="counter">
                                                            <b className="badge bg-danger"></b>
                                                        </span>

                                                    </sup>
                                                </Link>
                                            </li>


                                             <li>
                                        <a href="">
                                            <i className="fa fa-credit-card"></i> Payments
                                        <i className="fa arrow"></i>
                                        </a>
                                        <ul className="sidebar-nav">
                                            <li className="">
                                                <a href="payments-active.html"> Active </a>
                                            </li>
                                            <li className="">
                                                <a href="payments-expired.html"> Expired </a>
                                            </li>
                                            <li className="">
                                                <a href="payments-commissions.html"> Commissions </a>
                                            </li>
                                        </ul>
                                    </li>













                                        */}




    /*logSig = () => {
       const signaturedata = this.signaturePad.toDataURL();
        let oldContent = this.state.editorContent;
        let elem = oldContent ? oldContent + '<img alt src=' + signaturedata + ' />' : '<img alt src=' + signaturedata + ' />';
        this.setState({
            openSignatureDialog: false,
            editorContent: elem
        })
        console.log("signaturedata", signaturedata);

    }

    logSig = () => {
        
        const signaturedata = this.signaturePad.toDataURL();
        let oldContent = this.state.editorContent;
        
        let elem= oldContent ? oldContent + '<img alt src=' + signaturedata + ' />' :'<img alt src=' + signaturedata + ' />';
        this.setState({
            openSignatureDialog: false,
            editorContent:elem
        })
        console.log("signaturedata", signaturedata);

    }
*/


