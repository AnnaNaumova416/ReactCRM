import React from 'react';
import { Link } from 'react-router';

class Home extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
           
        };

    }

render() {
        return (
            <div style={{textAlign: "center", paddingTop: '200px'}}> 
                <strong><h1>COMING SOON </h1></strong>
             </div>
        )
    }
}

export default Home;





 